LAST DAYS
=========
**LAST DAYS** was a texture pack started by **[doku](http://www.minecraftforum.net/user/14329-)** (creator of the ever-popular [RPG pack](http://www.minecraftforum.net/topic/513093-)).  Doku began this pack with the essential land-scape defining textures (Dirt, Grass, Stone, water, trees, etc) but did not have time to do much more before discontinuing the pack.  The concept he had, and the work he finished was too good to let die.  Using Doku's visual and conceptual foundation, "**[History](http://www.minecraftforum.net/user/53403-)**" continued the pack, expanded it, and improved it.  After History's disappearance, the pack was continued and further-improved by **[Croco15](http://www.minecraftforum.net/user/158674-)** and **[HalphPrice](http://www.minecraftforum.net/user/249941-)**.  Finally, **[dereksmith](http://www.minecraftforum.net/user/98378-)** has chosen to keep LAST DAYS updated with the help of the community and continue to improve it, just like the other texture pack owners had before.  

* **Threads:**
 * The [Original Thread](http://www.minecraftforum.net/topic/30422-) by [doku](http://www.minecraftforum.net/user/14329-)
 * The [Second Thread](http://www.minecraftforum.net/topic/126176-) by [History](http://www.minecraftforum.net/user/53403-)
 * The [Third Thread](http://www.minecraftforum.net/topic/369814-) by [Croco15](http://www.minecraftforum.net/user/158674-)
 * The [Fourth (current) Thread](http://www.minecraftforum.net/topic/1059319-) by [dereksmith](http://www.minecraftforum.net/user/98378-)
* **Downloads:**
 * [Home Page for Downloads and Info](http://zerolevels.github.io/LAST_DAYS/)
